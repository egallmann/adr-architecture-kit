# Bootstrap Prompts - Prompt Translator Implementation

**Date**: 2026-03-08  
**Authority**: ADR-L-0005, ADR-P-0004  
**Purpose**: Hand-crafted prompts to implement the prompt translator (last manual prompts!)

---

## Overview

These are the **last prompts we'll hand-craft**. Once the prompt translator is implemented, it will generate all future prompts automatically from ADRs.

**Bootstrap sequence**:
1. Use these manual prompts → Implement prompt translator
2. Use prompt translator → Generate prompts for decorator library
3. Use prompt translator → Generate prompts for all future components

---

## Prompt 1: Implement ComponentParser (COMP-0005)

**Authority**: ADR-P-0004 COMP-0005  
**Logical ADR**: ADR-L-0005  
**Target**: CODEX

### Context
You are implementing the ADR Component Parser for the ADR Architecture Kit. This module parses Physical ADRs and extracts component specifications into structured data that can be used to generate implementation prompts.

### Constraints (MUST enforce)

**INV-0027** (ADR-L-0005):
Generated prompts MUST include all invariants from the source ADR with their enforcement levels (must/should/may).

**INV-0028** (ADR-L-0005):
Generated prompts MUST include component specifications with complete interface definitions (methods, parameters, return types).

**INV-0029** (ADR-L-0005):
Generated prompts MUST reference the source ADR ID and specific sections for traceability.

**INV-0032** (ADR-L-0005):
Prompt generator MUST be deterministic - same ADR input always produces same prompt output.

### Component Specification (COMP-0005)

**Files**:
- `src/adr_kit/prompts/__init__.py`
- `src/adr_kit/prompts/parser.py`

**Dataclasses**:

```python
@dataclass
class InterfaceSpec:
    """Specification for a class, method, or dataclass interface."""
    name: str
    type: str  # 'class', 'method', 'dataclass', 'function'
    description: Optional[str] = None
    fields: List[Dict[str, str]] = field(default_factory=list)  # For dataclasses
    methods: List[Dict[str, str]] = field(default_factory=list)  # For classes
    parameters: List[Dict[str, str]] = field(default_factory=list)  # For methods/functions
    returns: Optional[str] = None

@dataclass
class InvariantRef:
    """Reference to an invariant from a Logical ADR."""
    id: str
    statement: str
    enforcement_level: str
    rationale: str
    source_adr: str  # Logical ADR ID

@dataclass
class CapabilityRef:
    """Reference to a capability from a Logical ADR."""
    id: str
    name: str
    description: str
    acceptance_criteria: List[str]
    source_adr: str

@dataclass
class ImplDecisionRef:
    """Reference to an implementation decision."""
    id: str
    title: str
    rationale: str
    source_adr: str

@dataclass
class ComponentSpec:
    """Complete specification for a component extracted from Physical ADR."""
    id: str
    name: str
    type: str
    description: str
    responsibilities: List[str]
    interfaces: List[InterfaceSpec]
    implementation_identifiers: List[str]
    dependencies: List[str]
    testing_requirements: List[str]
    related_invariants: List[InvariantRef]
    related_capabilities: List[CapabilityRef]
    implementation_decisions: List[ImplDecisionRef]
    source_adr: str  # Physical ADR ID
    logical_adr: Optional[str] = None  # Logical ADR ID
```

**Class**: `ComponentParser`

```python
class ComponentParser:
    def __init__(self, adr_parser: Optional[ADRParser] = None):
        self.adr_parser = adr_parser or ADRParser()
    
    def parse_physical_adr(self, adr_path: Path) -> List[ComponentSpec]:
        """
        Parse Physical ADR and extract all component specifications.
        
        Returns list of ComponentSpec objects, one per COMP-* section.
        """
        # 1. Parse Physical ADR YAML
        # 2. Extract component_specifications section
        # 3. For each component, create ComponentSpec
        # 4. Load related Logical ADR (from implements_logical)
        # 5. Extract related invariants, capabilities
        # 6. Return list of ComponentSpec objects
    
    def load_logical_adr(self, logical_id: str) -> Optional[LogicalADR]:
        """Load Logical ADR by ID."""
        # Search adrs/logical/ for matching ID
    
    def extract_related_invariants(
        self, 
        component: ComponentSpec, 
        logical: LogicalADR
    ) -> List[InvariantRef]:
        """
        Find invariants from Logical ADR relevant to this component.
        
        Match by:
        - Keywords in component responsibilities
        - References in testing_requirements
        - Enforcement level (prioritize 'must')
        """
    
    def extract_related_capabilities(
        self,
        component: ComponentSpec,
        logical: LogicalADR
    ) -> List[CapabilityRef]:
        """Find capabilities relevant to this component."""
```

### Test Requirements

**File**: `tests/test_component_parser.py`

```python
class TestComponentParser:
    @pytest.fixture
    def parser(self):
        return ComponentParser()
    
    def test_parse_adr_p_0003(self, parser):
        """Parse real Physical ADR (ADR-P-0003)."""
        adr_path = Path("adrs/physical/ADR-P-0003-multi-scope-python-implementation.yaml")
        components = parser.parse_physical_adr(adr_path)
        
        assert len(components) == 4
        assert components[0].id == "COMP-0001"
        assert components[0].name == "Project Scope Resolver"
    
    def test_extract_component_interfaces(self, parser):
        """Extract interface definitions from component."""
        # Test that interfaces are parsed correctly
    
    def test_load_logical_adr(self, parser):
        """Load related Logical ADR."""
        logical = parser.load_logical_adr("ADR-L-0002")
        assert logical is not None
        assert logical.id == "ADR-L-0002"
    
    def test_extract_related_invariants(self, parser):
        """Extract invariants relevant to component."""
        # Parse ADR-P-0003 COMP-0001
        # Load ADR-L-0002
        # Extract related invariants (should find INV-0015, INV-0018)
    
    def test_handles_missing_logical_adr(self, parser):
        """Gracefully handle missing Logical ADR."""
        # Test with Physical ADR that has no implements_logical
```

### Cooperative Signals

**Before starting**:
```bash
# Check if component already claimed
if [ -f .codex/signals/ADR-P-0004/COMP-0005.claim.json ]; then
    echo "Component COMP-0005 already claimed by another agent"
    exit 1
fi

# Claim component
python -c "
import json
from datetime import datetime
from pathlib import Path
Path('.codex/signals/ADR-P-0004').mkdir(parents=True, exist_ok=True)
signal = {
    'signal_type': 'claim',
    'component_id': 'COMP-0005',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z'
}
with open('.codex/signals/ADR-P-0004/COMP-0005.claim.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0005 claimed')
"
```

**During implementation** (emit progress signals):
```bash
# After writing tests
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'progress',
    'component_id': 'COMP-0005',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'status': 'tests_written', 'tests_total': 5}
}
with open('.codex/signals/ADR-P-0004/COMP-0005.progress.json', 'w') as f:
    json.dump(signal, f, indent=2)
"

# After implementation
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'progress',
    'component_id': 'COMP-0005',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'status': 'implementation_complete', 'tests_passing': 5, 'tests_total': 5}
}
with open('.codex/signals/ADR-P-0004/COMP-0005.progress.json', 'w') as f:
    json.dump(signal, f, indent=2)
"
```

**After completion**:
```bash
# Emit completion signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'complete',
    'component_id': 'COMP-0005',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {
        'tests_passing': 5,
        'tests_total': 5,
        'files_created': [
            'src/adr_kit/prompts/__init__.py',
            'src/adr_kit/prompts/parser.py',
            'tests/test_component_parser.py'
        ]
    }
}
with open('.codex/signals/ADR-P-0004/COMP-0005.complete.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0005 complete')
"
```

### Implementation Strategy (TDD)

**Red-Green-Refactor**:
1. **Red**: Write `test_parse_adr_p_0003` (fails - parser doesn't exist)
2. **Green**: Implement basic `parse_physical_adr()` to pass
3. **Refactor**: Extract component parsing logic
4. **Red**: Write `test_load_logical_adr` (fails)
5. **Green**: Implement `load_logical_adr()`
6. **Refactor**: Extract ADR loading logic
7. **Red**: Write `test_extract_related_invariants` (fails)
8. **Green**: Implement invariant extraction
9. **Refactor**: Extract matching logic

### Dependencies
```python
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from adr_kit.parser import ADRParser
from adr_kit.models import LogicalADR, PhysicalADR
```

### Validation Criteria

I will verify:
- ✅ Parses ADR-P-0003 successfully
- ✅ Extracts all 4 components (COMP-0001 through COMP-0004)
- ✅ Loads ADR-L-0002 correctly
- ✅ Extracts relevant invariants (INV-0015, INV-0018 for COMP-0001)
- ✅ All tests pass
- ✅ Type hints complete
- ✅ Docstrings present

---

## Prompt 2: Implement PromptGenerator (COMP-0006)

**Authority**: ADR-P-0004 COMP-0006  
**Target**: CODEX

### Context
You are implementing the Prompt Generator for the ADR Architecture Kit. This module uses Jinja2 templates to render implementation prompts from component specifications.

### Constraints (MUST enforce)

**INV-0027**: Include all invariants with enforcement levels  
**INV-0028**: Include complete interface definitions  
**INV-0029**: Reference source ADR ID  
**INV-0030**: Include test requirements  
**INV-0032**: Deterministic generation  

### Component Specification (COMP-0006)

**Files**:
- `src/adr_kit/prompts/generator.py`
- `src/adr_kit/prompts/templates/implementation-prompt.md.jinja2`
- `src/adr_kit/prompts/templates/validation-checklist.md.jinja2`
- `src/adr_kit/prompts/templates/execution-plan.md.jinja2`

**Class**: `PromptGenerator`

```python
class PromptGenerator:
    def __init__(self, template_dir: Optional[Path] = None):
        self.template_dir = template_dir or (Path(__file__).parent / "templates")
        self.jinja_env = Environment(loader=FileSystemLoader(self.template_dir))
    
    def generate_implementation_prompt(
        self,
        component: ComponentSpec,
        target: str = "codex"
    ) -> str:
        """
        Generate implementation prompt for a component.
        
        Args:
            component: Component specification
            target: Target agent (codex, cursor, claude, gpt)
        
        Returns:
            Markdown prompt string
        """
        template = self.jinja_env.get_template("implementation-prompt.md.jinja2")
        return template.render(
            component=component,
            target=target,
            methodology="test-driven-development"  # From PROJECT.yaml
        )
    
    def generate_validation_checklist(
        self,
        components: List[ComponentSpec],
        adr_id: str
    ) -> str:
        """Generate validation checklist for all components."""
        template = self.jinja_env.get_template("validation-checklist.md.jinja2")
        return template.render(components=components, adr_id=adr_id)
    
    def generate_execution_plan(
        self,
        components: List[ComponentSpec]
    ) -> str:
        """Generate execution plan with dependency ordering."""
        # Use DependencyAnalyzer to determine order
        template = self.jinja_env.get_template("execution-plan.md.jinja2")
        return template.render(components=components)
```

### Template Structure

**File**: `src/adr_kit/prompts/templates/implementation-prompt.md.jinja2`

```jinja2
# Implementation Prompt: {{ component.name }} ({{ component.id }})

**Authority**: {{ component.source_adr }} {{ component.id }}
{% if component.logical_adr %}
**Logical ADR**: {{ component.logical_adr }}
{% endif %}
**Target Agent**: {{ target }}

## Context
You are implementing {{ component.name }} for the ADR Architecture Kit.
{{ component.description }}

## Constraints (MUST enforce)
{% for invariant in component.related_invariants %}
**{{ invariant.id }}** ({{ invariant.source_adr }}):
{{ invariant.statement }}
- Enforcement level: {{ invariant.enforcement_level }}
- Rationale: {{ invariant.rationale }}

{% endfor %}

## Component Specification ({{ component.id }})

**Type**: {{ component.type }}

**Files**:
{% for file in component.implementation_identifiers %}
- `{{ file }}`
{% endfor %}

**Responsibilities**:
{% for resp in component.responsibilities %}
- {{ resp }}
{% endfor %}

**Interfaces**:
{% for interface in component.interfaces %}
### {{ interface.name }}
**Type**: {{ interface.type }}

{% if interface.fields %}
**Fields**:
{% for field in interface.fields %}
- `{{ field.name }}: {{ field.type }}` - {{ field.description }}
{% endfor %}
{% endif %}

{% if interface.methods %}
**Methods**:
{% for method in interface.methods %}
- `{{ method.signature }}`
  {{ method.description }}
{% endfor %}
{% endif %}
{% endfor %}

## Test Requirements

**File**: `tests/test_{{ component.name|lower|replace(' ', '_') }}.py`

Required tests:
{% for test in component.testing_requirements %}
- `{{ test }}`
{% endfor %}

## Implementation Strategy (TDD)

**Red-Green-Refactor Cycle** (per ADR-L-0003):
1. **Red**: Write failing test
2. **Green**: Implement to pass test
3. **Refactor**: Improve design while keeping tests green

## Dependencies
```python
{% for dep in component.dependencies %}
{{ dep }}
{% endfor %}
```

## Validation Criteria

I will verify:
{% for invariant in component.related_invariants %}
- ✅ {{ invariant.id }} enforced
{% endfor %}
{% for test in component.testing_requirements %}
- ✅ Test exists: `{{ test }}`
{% endfor %}
- ✅ All tests pass
- ✅ Type hints complete
- ✅ Docstrings present
```

### Test Requirements

**File**: `tests/test_prompt_generator.py`

```python
class TestPromptGenerator:
    @pytest.fixture
    def generator(self):
        return PromptGenerator()
    
    @pytest.fixture
    def sample_component(self):
        """Create sample ComponentSpec for testing."""
        return ComponentSpec(
            id="COMP-0001",
            name="Project Scope Resolver",
            type="module",
            description="Detects project boundaries",
            responsibilities=["Detect boundaries", "Enforce boundaries"],
            interfaces=[
                InterfaceSpec(
                    name="ProjectScope",
                    type="dataclass",
                    fields=[
                        {"name": "root", "type": "Path", "description": "Project root"}
                    ]
                )
            ],
            implementation_identifiers=["src/adr_kit/scope/resolver.py"],
            dependencies=["pathlib.Path"],
            testing_requirements=["test_detect_scope"],
            related_invariants=[
                InvariantRef(
                    id="INV-0015",
                    statement="MUST use marker hierarchy",
                    enforcement_level="must",
                    rationale="Consistency",
                    source_adr="ADR-L-0002"
                )
            ],
            related_capabilities=[],
            implementation_decisions=[],
            source_adr="ADR-P-0003"
        )
    
    def test_generate_implementation_prompt(self, generator, sample_component):
        """Generate implementation prompt from component spec."""
        prompt = generator.generate_implementation_prompt(sample_component)
        
        # Verify required sections present
        assert "# Implementation Prompt: Project Scope Resolver" in prompt
        assert "## Context" in prompt
        assert "## Constraints" in prompt
        assert "INV-0015" in prompt
        assert "## Component Specification" in prompt
        assert "## Test Requirements" in prompt
        assert "test_detect_scope" in prompt
        assert "## Validation Criteria" in prompt
    
    def test_prompt_includes_all_invariants(self, generator, sample_component):
        """Verify all invariants included (INV-0027)."""
        prompt = generator.generate_implementation_prompt(sample_component)
        
        for invariant in sample_component.related_invariants:
            assert invariant.id in prompt
            assert invariant.statement in prompt
            assert invariant.enforcement_level in prompt
    
    def test_prompt_is_deterministic(self, generator, sample_component):
        """Verify deterministic generation (INV-0032)."""
        prompt1 = generator.generate_implementation_prompt(sample_component)
        prompt2 = generator.generate_implementation_prompt(sample_component)
        
        assert prompt1 == prompt2
    
    def test_generate_validation_checklist(self, generator, sample_component):
        """Generate validation checklist."""
        checklist = generator.generate_validation_checklist(
            [sample_component],
            "ADR-P-0003"
        )
        
        assert "# Validation Checklist - ADR-P-0003" in checklist
        assert "COMP-0001" in checklist
        assert "INV-0015" in checklist
    
    def test_generate_with_real_adr_p_0003(self, generator):
        """Test with real Physical ADR."""
        parser = ComponentParser()
        components = parser.parse_physical_adr(
            Path("adrs/physical/ADR-P-0003-multi-scope-python-implementation.yaml")
        )
        
        # Generate prompt for first component
        prompt = generator.generate_implementation_prompt(components[0])
        
        assert "COMP-0001" in prompt
        assert "Project Scope Resolver" in prompt
```

### Cooperative Signals

**Before starting**:
```bash
# Check dependency: COMP-0005 must be complete
if [ ! -f .codex/signals/ADR-P-0004/COMP-0005.complete.json ]; then
    echo "Waiting for COMP-0005 (ComponentParser) to complete..."
    exit 1
fi

# Claim component
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'claim',
    'component_id': 'COMP-0006',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z'
}
with open('.codex/signals/ADR-P-0004/COMP-0006.claim.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0006 claimed')
"
```

**During implementation**:
```bash
# Emit progress after tests written
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'progress',
    'component_id': 'COMP-0006',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'status': 'tests_written', 'tests_total': 8}
}
with open('.codex/signals/ADR-P-0004/COMP-0006.progress.json', 'w') as f:
    json.dump(signal, f, indent=2)
"
```

**After completion**:
```bash
# Emit completion signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'complete',
    'component_id': 'COMP-0006',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'tests_passing': 8, 'tests_total': 8}
}
with open('.codex/signals/ADR-P-0004/COMP-0006.complete.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0006 complete')
"
```

### Implementation Strategy (TDD)

1. **Red**: Write `test_generate_implementation_prompt` (fails - no template)
2. **Green**: Create basic template and implement `generate_implementation_prompt()`
3. **Refactor**: Improve template structure
4. **Red**: Write `test_prompt_includes_all_invariants` (fails)
5. **Green**: Update template to include all invariants
6. **Refactor**: Extract invariant formatting
7. **Red**: Write `test_prompt_is_deterministic` (fails if non-deterministic)
8. **Green**: Ensure template rendering is deterministic
9. Continue for validation checklist and execution plan...

### Dependencies
```python
from pathlib import Path
from typing import Optional, List
from jinja2 import Environment, FileSystemLoader
from adr_kit.prompts.parser import ComponentSpec
```

### Validation Criteria

I will verify:
- ✅ All invariants included in prompt (INV-0027)
- ✅ Complete interface definitions (INV-0028)
- ✅ Source ADR referenced (INV-0029)
- ✅ Test requirements included (INV-0030)
- ✅ Deterministic generation (INV-0032)
- ✅ All tests pass
- ✅ Template is readable and well-structured

---

## Prompt 3: Implement CLI Command (COMP-0007)

**Authority**: ADR-P-0004 COMP-0007  
**Target**: CODEX

### Context
You are adding a new CLI command `generate-prompts` to the existing ADR CLI. This command generates implementation prompts from Physical ADRs.

### Component Specification (COMP-0007)

**File**: `src/adr_kit/cli/main.py` (modify existing)

**New Command**:
```python
@cli.command('generate-prompts')
@click.argument('adr_id')
@click.option('--component', help='Specific component ID (e.g., COMP-0001)')
@click.option('--target', default='codex', help='Target agent (codex, cursor, claude, gpt)')
@click.option('--output', type=click.Path(), required=True, help='Output directory')
@click.option('--format', default='markdown', help='Output format (markdown, json)')
def generate_prompts(adr_id, component, target, output, format):
    """Generate implementation prompts from Physical ADR."""
    
    # 1. Find Physical ADR by ID
    # 2. Parse components using ComponentParser
    # 3. Filter to specific component if --component provided
    # 4. Generate prompts using PromptGenerator
    # 5. Write prompts to output directory
    # 6. Generate validation checklist
    # 7. Generate execution plan
    # 8. Display summary
```

### Test Requirements

**File**: `tests/test_prompt_cli.py`

```python
def test_generate_prompts_all_components():
    """Test generating prompts for all components."""
    result = runner.invoke(cli, [
        'generate-prompts', 
        'ADR-P-0003',
        '--output', 'test-output/'
    ])
    
    assert result.exit_code == 0
    assert Path("test-output/ADR-P-0003/COMP-0001-scope-resolver.md").exists()
    assert Path("test-output/ADR-P-0003/validation-checklist.md").exists()

def test_generate_prompts_single_component():
    """Test generating prompt for specific component."""
    result = runner.invoke(cli, [
        'generate-prompts',
        'ADR-P-0003',
        '--component', 'COMP-0001',
        '--output', 'test-output/'
    ])
    
    assert result.exit_code == 0
    assert Path("test-output/ADR-P-0003/COMP-0001-scope-resolver.md").exists()
```

### Cooperative Signals

**Before starting**:
```bash
# Check dependencies: COMP-0005 and COMP-0006 must be complete
if [ ! -f .codex/signals/ADR-P-0004/COMP-0005.complete.json ] || [ ! -f .codex/signals/ADR-P-0004/COMP-0006.complete.json ]; then
    echo "Waiting for COMP-0005 and COMP-0006 to complete..."
    exit 1
fi

# Claim component
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'claim',
    'component_id': 'COMP-0007',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z'
}
with open('.codex/signals/ADR-P-0004/COMP-0007.claim.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0007 claimed')
"
```

**After completion**:
```bash
# Emit completion signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'complete',
    'component_id': 'COMP-0007',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'tests_passing': 5, 'tests_total': 5}
}
with open('.codex/signals/ADR-P-0004/COMP-0007.complete.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0007 complete')
"
```

### Implementation Strategy (TDD)

1. **Red**: Write CLI test (fails - command doesn't exist)
2. **Green**: Add command skeleton
3. **Red**: Test prompt file creation
4. **Green**: Implement file writing
5. **Refactor**: Extract common logic

### Validation Criteria

I will verify:
- ✅ CLI command works: `adr generate-prompts ADR-P-0003 --output prompts/`
- ✅ Generates all component prompts
- ✅ Generates validation checklist
- ✅ Generates execution plan
- ✅ `--component` filter works
- ✅ Help text clear

---

## Prompt 4: Implement DependencyAnalyzer (COMP-0008)

**Authority**: ADR-P-0004 COMP-0008  
**Target**: CODEX

### Context
You are implementing the Dependency Analyzer for the ADR Architecture Kit. This module analyzes component dependencies to generate execution order for implementation.

### Component Specification (COMP-0008)

**File**: `src/adr_kit/prompts/dependencies.py`

**Class**: `DependencyAnalyzer`

```python
class DependencyAnalyzer:
    def analyze(self, components: List[ComponentSpec]) -> Dict[str, List[str]]:
        """
        Build dependency graph from components.
        
        Returns dict mapping component ID to list of dependency IDs.
        """
        # Parse component.dependencies
        # Match against component.implementation_identifiers
        # Build adjacency list
    
    def get_execution_order(
        self,
        components: List[ComponentSpec]
    ) -> List[List[ComponentSpec]]:
        """
        Get topologically sorted execution order.
        
        Returns list of "waves" where components in same wave can be
        implemented in parallel.
        """
        # Topological sort
        # Group by depth level (wave)
    
    def detect_circular(
        self,
        components: List[ComponentSpec]
    ) -> Optional[List[str]]:
        """
        Detect circular dependencies.
        
        Returns list of component IDs in cycle, or None if no cycle.
        """
        # DFS cycle detection
```

### Test Requirements

```python
def test_linear_dependencies():
    """Test A → B → C linear chain."""
    components = [
        ComponentSpec(id="A", dependencies=[]),
        ComponentSpec(id="B", dependencies=["A"]),
        ComponentSpec(id="C", dependencies=["B"])
    ]
    
    analyzer = DependencyAnalyzer()
    order = analyzer.get_execution_order(components)
    
    assert len(order) == 3
    assert order[0][0].id == "A"
    assert order[1][0].id == "B"
    assert order[2][0].id == "C"

def test_parallel_components():
    """Test A → B, A → C (B and C can parallelize)."""
    # Wave 1: [A]
    # Wave 2: [B, C] (parallel)

def test_circular_dependency_detection():
    """Test A → B → C → A cycle."""
    # Should detect cycle and return ["A", "B", "C"]
```

### Cooperative Signals

**Before starting**:
```bash
# Check if component already claimed
if [ -f .codex/signals/ADR-P-0004/COMP-0008.claim.json ]; then
    echo "Component COMP-0008 already claimed"
    exit 1
fi

# Claim component (can run in parallel with COMP-0005, no dependencies)
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'claim',
    'component_id': 'COMP-0008',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z'
}
with open('.codex/signals/ADR-P-0004/COMP-0008.claim.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0008 claimed')
"
```

**After completion**:
```bash
# Emit completion signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'complete',
    'component_id': 'COMP-0008',
    'adr_id': 'ADR-P-0004',
    'agent': 'codex',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'tests_passing': 4, 'tests_total': 4}
}
with open('.codex/signals/ADR-P-0004/COMP-0008.complete.json', 'w') as f:
    json.dump(signal, f, indent=2)
print('Component COMP-0008 complete')
"

# Check if Wave 1 complete (COMP-0005 and COMP-0008)
python -c "
import json
from datetime import datetime
from pathlib import Path
if Path('.codex/signals/ADR-P-0004/COMP-0005.complete.json').exists() and Path('.codex/signals/ADR-P-0004/COMP-0008.complete.json').exists():
    signal = {
        'signal_type': 'wave_complete',
        'wave_num': 1,
        'adr_id': 'ADR-P-0004',
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'metadata': {
            'components': ['COMP-0005', 'COMP-0008'],
            'next_wave': ['COMP-0006']
        }
    }
    with open('.codex/signals/ADR-P-0004/wave-1.complete.json', 'w') as f:
        json.dump(signal, f, indent=2)
    print('Wave 1 complete - COMP-0006 can start')
"
```

### Validation Criteria

I will verify:
- ✅ Correctly orders linear dependencies
- ✅ Identifies parallelizable components
- ✅ Detects circular dependencies
- ✅ All tests pass

---

## Implementation Order

Execute prompts in this order (dependencies):

### Wave 1 (Parallel)
1. **Prompt 1** (COMP-0005: ComponentParser) - Foundation, no dependencies
2. **Prompt 4** (COMP-0008: DependencyAnalyzer) - Independent utility

**Wave 1 signal**: After both complete, `wave-1.complete.json` emitted

### Wave 2 (Sequential)
3. **Prompt 2** (COMP-0006: PromptGenerator) - Depends on COMP-0005
4. **Prompt 3** (COMP-0007: CLI) - Depends on COMP-0005 + COMP-0006

**Coordination**: Each prompt includes signal checks/emissions for dependency satisfaction

---

## Success Criteria

Implementation is complete when:

✅ Can parse ADR-P-0003 and extract 4 components  
✅ Can generate implementation prompts for each component  
✅ Can generate validation checklist  
✅ Can generate execution plan  
✅ CLI works: `adr generate-prompts ADR-P-0003 --output prompts/`  
✅ All tests pass (20+ tests)  
✅ Prompts are deterministic (INV-0032)  
✅ Prompts include all invariants (INV-0027)  

---

## Self-Validation Test

**The ultimate test**: Use the prompt translator to generate prompts for itself!

```bash
# After implementation is complete
adr generate-prompts ADR-P-0004 --output prompts/

# Should generate:
# - prompts/ADR-P-0004/COMP-0005-component-parser.md
# - prompts/ADR-P-0004/COMP-0006-prompt-generator.md
# - prompts/ADR-P-0004/COMP-0007-cli.md
# - prompts/ADR-P-0004/COMP-0008-dependency-analyzer.md

# Compare generated prompts to these hand-crafted prompts
# They should be structurally similar!
```

---

**These are the last manual prompts. After this, ADRs generate prompts automatically!**
