# Agent-Specific Prompt Optimization

**Date**: 2026-03-08  
**Authority**: ADR-P-0004 IMPL-0008  
**Purpose**: Optimize prompts for different AI agent capabilities

---

## Overview

Different AI agents have different strengths and optimal prompt formats. The prompt translator supports generating agent-specific prompts while maintaining **core content consistency**.

**Core principle**: Same invariants, specs, and tests - different presentation.

---

## Supported Agents

### 1. CODEX (GitHub Copilot)

**Strengths**:
- Fast code generation
- Excellent at pattern matching
- Works well with concise prompts
- Strong at completing partial code

**Optimal Format**:
- **Concise**: Get to the code quickly
- **Code-focused**: Emphasize interface signatures and examples
- **Pattern-driven**: Show code patterns to follow
- **Minimal context**: Just enough to understand task

**Template**: `templates/codex-prompt.md.jinja2`

**Example Structure**:
```markdown
# Implement: ComponentParser (COMP-0005)

## Spec
File: `src/adr_kit/prompts/parser.py`

```python
class ComponentParser:
    def parse_physical_adr(self, adr_path: Path) -> List[ComponentSpec]:
        """Parse Physical ADR and extract components."""
```

## Constraints
- INV-0027: Include all invariants
- INV-0032: Deterministic generation

## Tests
```python
def test_parse_adr_p_0003():
    parser = ComponentParser()
    components = parser.parse_physical_adr(Path("adrs/physical/ADR-P-0003-...yaml"))
    assert len(components) == 4
```

## Dependencies
```python
from pathlib import Path
from typing import List
import yaml
```
```

**Characteristics**:
- ✅ Minimal prose
- ✅ Maximum code examples
- ✅ Clear interface signatures
- ✅ Concrete test cases

---

### 2. Cursor (Claude Sonnet 4.5)

**Strengths**:
- Deep reasoning capabilities
- Excellent context understanding
- Long context window (200K tokens)
- Strong at architectural thinking
- Benefits from detailed rationale

**Optimal Format**:
- **Detailed**: Provide full context and reasoning
- **Reasoning-focused**: Explain why decisions were made
- **Architectural**: Show how component fits in system
- **Rationale-rich**: Include ADR rationale and alternatives

**Template**: `templates/cursor-prompt.md.jinja2`

**Example Structure**:
```markdown
# Implementation: ComponentParser (COMP-0005)

**Authority**: ADR-P-0004 COMP-0005  
**Logical ADR**: ADR-L-0005  
**Model**: Claude Sonnet 4.5

## Architectural Context

The ComponentParser is part of the ADR-to-Prompt translation system, which
transforms machine-readable ADRs into implementation prompts for AI agents.

**Why this exists**: Manual prompt crafting doesn't scale. ADRs contain all
necessary specifications (invariants, interfaces, tests), so we can automate
prompt generation.

**How it fits**: 
- Reads Physical ADRs (YAML)
- Extracts component specifications
- Feeds PromptGenerator for rendering
- Enables automated implementation pipelines

## Design Rationale

**From ADR-L-0005 DEC-0001**:
> "Automate the generation of implementation prompts from ADR specifications
> to ensure consistency, completeness, and scalability."

**Key insight**: ADRs are machine-readable specs. We can parse them
deterministically and generate prompts that include all constraints.

## Constraints (Invariants to Enforce)

**INV-0027** (must): Include all invariants from source ADR
- **Why**: Missing invariants → non-compliant code
- **How to enforce**: Parse logical ADR, extract all INV-* sections
- **Validation**: Generated prompt contains all invariant IDs

**INV-0028** (must): Include complete interface definitions
- **Why**: Incomplete specs → incorrect implementations
- **How to enforce**: Parse component interfaces, include all methods/params
- **Validation**: Generated prompt has full method signatures

**INV-0032** (must): Deterministic generation
- **Why**: SYS-2 (Deterministic Cognition) - reproducibility required
- **How to enforce**: Use templates (no LLM), no timestamps in output
- **Validation**: Same input → same output (test with multiple runs)

## Component Specification (COMP-0005)

**Purpose**: Parse Physical ADRs and extract structured component data

**File**: `src/adr_kit/prompts/parser.py`

**Interface**:
```python
@dataclass
class ComponentSpec:
    """Complete specification for a component."""
    id: str                              # COMP-0001
    name: str                            # Project Scope Resolver
    type: str                            # module, class, enhancement
    description: str
    responsibilities: List[str]
    interfaces: List[InterfaceSpec]
    implementation_identifiers: List[str]
    dependencies: List[str]
    testing_requirements: List[str]
    related_invariants: List[InvariantRef]
    related_capabilities: List[CapabilityRef]
    implementation_decisions: List[ImplDecisionRef]
    source_adr: str

class ComponentParser:
    def parse_physical_adr(self, adr_path: Path) -> List[ComponentSpec]:
        """Parse Physical ADR and extract all component specifications."""
```

**Responsibilities**:
1. Parse Physical ADR YAML
2. Extract component_specifications section
3. Load related Logical ADR (from implements_logical)
4. Extract relevant invariants for each component
5. Extract relevant capabilities for each component
6. Build structured ComponentSpec objects

## Implementation Strategy (TDD)

**Methodology**: Red-Green-Refactor (per PROJECT.yaml, ADR-L-0003)

**Why TDD for this component**:
- Parser correctness is critical (feeds all prompt generation)
- Complex parsing logic benefits from test-first design
- Tests serve as specification for parsing behavior
- Refactoring safety net for optimization

**Cycle**:
1. **Red**: Write test for parsing ADR-P-0003 (real Physical ADR)
2. **Green**: Implement basic parsing to pass
3. **Refactor**: Extract component extraction logic
4. **Red**: Write test for loading Logical ADR
5. **Green**: Implement Logical ADR loading
6. **Refactor**: Add caching for performance
7. Continue...

## Test Requirements

**File**: `tests/test_component_parser.py`

**Required tests** (from ADR-P-0004):
1. `test_parse_adr_p_0003` - Parse real Physical ADR
2. `test_extract_component_interfaces` - Extract interface definitions
3. `test_load_logical_adr` - Load related Logical ADR
4. `test_extract_related_invariants` - Find relevant invariants
5. `test_handles_missing_logical_adr` - Graceful degradation

**Test strategy**:
- Use real ADRs (ADR-P-0003) for integration testing
- Test edge cases (missing fields, invalid YAML)
- Test error handling (file not found, parse errors)

## Dependencies

```python
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Optional, Dict
import yaml
from adr_kit.parser import ADRParser
from adr_kit.models import LogicalADR, PhysicalADR
```

## Validation Criteria

I will verify:
- ✅ Parses ADR-P-0003 successfully (4 components extracted)
- ✅ Loads ADR-L-0002 correctly (related Logical ADR)
- ✅ Extracts relevant invariants (INV-0015, INV-0018 for COMP-0001)
- ✅ All 5 tests passing
- ✅ Type hints complete
- ✅ Docstrings present with rationale
- ✅ Error handling graceful
```

**Characteristics**:
- ✅ Extensive context and rationale
- ✅ Explains "why" for each decision
- ✅ Shows architectural connections
- ✅ Detailed implementation strategy
- ✅ Reasoning-focused

---

### 3. Claude (API)

**Strengths**:
- Structured thinking
- Step-by-step reasoning
- Good at following procedures
- Strong at complex tasks

**Optimal Format**:
- **Structured**: Clear sections and steps
- **Procedural**: Step-by-step guidance
- **Thinking-oriented**: Include thinking sections
- **Methodical**: Emphasize process

**Template**: `templates/claude-prompt.md.jinja2`

**Example Structure**:
```markdown
# Task: Implement ComponentParser (COMP-0005)

## Thinking

Let me understand what I need to build:
- Parse Physical ADRs (YAML files)
- Extract component specifications
- Load related Logical ADRs
- Match invariants to components

This is a parser component, so correctness is critical.

## Context
[Detailed context...]

## Approach

I will implement this in steps:
1. Create dataclasses for structured data
2. Implement YAML parsing
3. Implement component extraction
4. Implement invariant matching
5. Write tests for each step

## Constraints
[Invariants with enforcement levels...]

## Implementation Steps

Step 1: Create ComponentSpec dataclass
Step 2: Implement parse_physical_adr()
Step 3: Implement load_logical_adr()
Step 4: Implement extract_related_invariants()
Step 5: Write comprehensive tests

## Validation
[Validation criteria...]
```

**Characteristics**:
- ✅ Thinking section for reasoning
- ✅ Clear step-by-step approach
- ✅ Procedural guidance
- ✅ Methodical structure

---

### 4. GPT (OpenAI)

**Strengths**:
- Pattern recognition
- Good with examples
- Fast generation
- Works well with demonstrations

**Optimal Format**:
- **Example-driven**: Show concrete examples
- **Pattern-focused**: Demonstrate patterns to follow
- **Clear instructions**: Direct, actionable steps
- **Demo-heavy**: More examples, less theory

**Template**: `templates/gpt-prompt.md.jinja2`

**Example Structure**:
```markdown
# Implement: ComponentParser (COMP-0005)

## What to Build

A parser that extracts component specs from Physical ADRs.

**Example Input** (ADR-P-0003):
```yaml
component_specifications:
  - id: COMP-0001
    name: Project Scope Resolver
    interfaces:
      - name: ProjectScope
        type: dataclass
```

**Example Output**:
```python
ComponentSpec(
    id="COMP-0001",
    name="Project Scope Resolver",
    interfaces=[
        InterfaceSpec(name="ProjectScope", type="dataclass")
    ]
)
```

## Pattern to Follow

**Similar parser in project**: `src/adr_kit/parser/yaml_parser.py`

```python
# Follow this pattern
class ADRParser:
    def parse_logical_adr(self, file_path: Path) -> LogicalADR:
        with open(file_path) as f:
            data = yaml.safe_load(f)
        return LogicalADR(**data)

# Your implementation should be similar
class ComponentParser:
    def parse_physical_adr(self, adr_path: Path) -> List[ComponentSpec]:
        # Follow same pattern
```

## Constraints
- Must include all invariants (INV-0027)
- Must be deterministic (INV-0032)

## Tests (Examples)
```python
def test_parse_adr_p_0003():
    parser = ComponentParser()
    components = parser.parse_physical_adr(Path("adrs/physical/ADR-P-0003-...yaml"))
    assert len(components) == 4
    assert components[0].id == "COMP-0001"
```
```

**Characteristics**:
- ✅ Heavy on examples
- ✅ Shows patterns from existing code
- ✅ Concrete demonstrations
- ✅ Less theory, more practice

---

## Template Inheritance

**Base Template**: `templates/base-prompt.md.jinja2`

Contains core structure that all agents share:
- Component specification
- Invariants
- Test requirements
- Validation criteria

**Agent Templates**: Extend base template

```jinja2
{# codex-prompt.md.jinja2 #}
{% extends "base-prompt.md.jinja2" %}

{% block style %}concise{% endblock %}

{% block context %}
{{ component.name }} - {{ component.description }}
{% endblock %}

{# Minimal context, maximum code #}
```

```jinja2
{# cursor-prompt.md.jinja2 #}
{% extends "base-prompt.md.jinja2" %}

{% block style %}detailed{% endblock %}

{% block context %}
## Architectural Context

{{ component.name }} is part of {{ system_name }}.

**Why this exists**: {{ rationale }}

**How it fits**: {{ architectural_position }}

## Design Rationale
{% for decision in impl_decisions %}
**{{ decision.id }}**: {{ decision.title }}
{{ decision.rationale }}
{% endfor %}
{% endblock %}

{# Extensive context and reasoning #}
```

---

## Usage

### Generate for CODEX (concise)
```bash
python scripts/codex-implement.py ADR-P-0004 --agent codex
# Generates concise, code-focused prompts
```

### Generate for Cursor (detailed)
```bash
python scripts/codex-implement.py ADR-P-0004 --agent cursor
# Generates detailed, reasoning-focused prompts
```

### Generate for Claude (structured)
```bash
python scripts/codex-implement.py ADR-P-0004 --agent claude
# Generates structured, step-by-step prompts
```

### Generate for GPT (example-driven)
```bash
python scripts/codex-implement.py ADR-P-0004 --agent gpt
# Generates example-heavy prompts
```

---

## Content Consistency

**All agent formats include**:
- ✅ All invariants (INV-0027)
- ✅ Complete interface specs (INV-0028)
- ✅ Source ADR references (INV-0029)
- ✅ Test requirements (INV-0030)
- ✅ Validation criteria

**What differs**:
- Presentation style (concise vs. detailed)
- Context depth (minimal vs. extensive)
- Code example density (few vs. many)
- Reasoning emphasis (implicit vs. explicit)

---

## When to Use Which Agent

### Use CODEX for:
- ✅ Straightforward implementations
- ✅ Pattern-based code generation
- ✅ Quick prototypes
- ✅ Well-defined interfaces

### Use Cursor (Sonnet 4.5) for:
- ✅ Complex architectural work
- ✅ Design decisions requiring reasoning
- ✅ Multi-file refactoring
- ✅ Validation and verification
- ✅ ADR creation and design

### Use Claude for:
- ✅ Procedural implementations
- ✅ Step-by-step transformations
- ✅ Complex algorithms
- ✅ Systematic testing

### Use GPT for:
- ✅ Pattern-heavy implementations
- ✅ Code following existing examples
- ✅ Quick iterations
- ✅ Standard patterns

---

## Template Implementation Priority

### Phase 1: Base Template
- [ ] `templates/base-prompt.md.jinja2` - Core structure

### Phase 2: Primary Agents
- [ ] `templates/codex-prompt.md.jinja2` - For CODEX
- [ ] `templates/cursor-prompt.md.jinja2` - For Cursor (Sonnet 4.5)

### Phase 3: Additional Agents
- [ ] `templates/claude-prompt.md.jinja2` - For Claude API
- [ ] `templates/gpt-prompt.md.jinja2` - For GPT models

---

## Validation Across Agents

**Same validation checklist** regardless of agent:

```markdown
# Validation Checklist - ADR-P-0004

## COMP-0005: ComponentParser

- [ ] File exists: src/adr_kit/prompts/parser.py
- [ ] Class exists: ComponentParser
- [ ] Method exists: parse_physical_adr()
- [ ] INV-0027 enforced: All invariants included
- [ ] INV-0032 enforced: Deterministic generation
- [ ] All 5 tests passing
```

**Why**: Implementation requirements are the same - only the prompt format differs.

---

## Future: Agent Capability Detection

**Potential enhancement**:

```python
class AgentCapabilities:
    """Detect agent capabilities and optimize prompts."""
    
    @staticmethod
    def detect_agent() -> AgentFormat:
        """Auto-detect which agent is being used."""
        # Check environment variables
        # Check IDE context
        # Default to 'cursor' if uncertain
    
    @staticmethod
    def get_optimal_format(agent: AgentFormat, task_complexity: str) -> str:
        """Get optimal prompt format for agent and task."""
        if agent == AgentFormat.CODEX and task_complexity == "simple":
            return "concise"
        elif agent == AgentFormat.CURSOR and task_complexity == "complex":
            return "detailed-reasoning"
        # ...
```

---

## Summary

**Agent-agnostic system** with **agent-specific optimization**:

- ✅ Same core content (invariants, specs, tests)
- ✅ Different presentation (concise vs. detailed)
- ✅ Optimized for agent strengths
- ✅ Consistent validation

**Script supports all agents**:
```bash
python scripts/codex-implement.py ADR-P-XXXX --agent [codex|cursor|claude|gpt]
```

**Bootstrap prompts** in `docs/BOOTSTRAP-PROMPTS.md` are currently **Cursor-optimized** (detailed, reasoning-focused) since they were hand-crafted in Cursor context.

For CODEX, you could:
1. Use the detailed prompts as-is (CODEX can handle them)
2. Manually condense them (one-time effort)
3. Implement prompt translator first, then generate CODEX-optimized prompts

**Recommendation**: Use detailed prompts for now - they work for all agents, just more verbose for CODEX.
