# Cooperative Signals for Parallel AI Agents

**Date**: 2026-03-08  
**Authority**: ADR-P-0004 COMP-0009  
**Purpose**: File-based coordination for parallel agent implementation

---

## Problem

When multiple AI agents work on the same ADR in parallel:
- **Agent A** implements COMP-0001
- **Agent B** implements COMP-0002 (depends on COMP-0001)

**Agent B needs to know**: Is COMP-0001 complete? Can I start?

**Without coordination**:
- Agent B might start too early (COMP-0001 not done)
- Both agents might claim same component (duplicate work)
- No visibility into what others are doing

---

## Solution: File-Based Signals

**Temporary coordination mechanism** until Rules & Signal Service (Tier 2) is built.

**Signals are files** in `.codex/signals/`:
```
.codex/signals/
├── ADR-P-0004/
│   ├── COMP-0005.claim.json       # Agent claimed component
│   ├── COMP-0005.progress.json    # Agent reports progress
│   ├── COMP-0005.complete.json    # Component complete
│   ├── wave-1.complete.json       # Wave 1 done
│   └── validation-ready.json      # Ready for validator
```

**Agents read/write signals** to coordinate work.

---

## Signal Types

### 1. Claim Signal

**Purpose**: Agent claims component to prevent duplicate work

**File**: `.codex/signals/ADR-P-XXXX/COMP-YYYY.claim.json`

```json
{
  "signal_type": "claim",
  "component_id": "COMP-0005",
  "adr_id": "ADR-P-0004",
  "agent": "codex",
  "timestamp": "2026-03-08T14:00:00Z",
  "metadata": {
    "agent_session": "codex-session-123",
    "estimated_duration": "30m"
  }
}
```

**Workflow**:
```python
# Agent A wants to implement COMP-0005
if signal_exists("COMP-0005.claim.json"):
    print("Component already claimed by another agent")
    return
else:
    emit_claim("COMP-0005", agent="codex")
    # Proceed with implementation
```

### 2. Progress Signal

**Purpose**: Agent broadcasts progress for monitoring

**File**: `.codex/signals/ADR-P-XXXX/COMP-YYYY.progress.json`

```json
{
  "signal_type": "progress",
  "component_id": "COMP-0005",
  "adr_id": "ADR-P-0004",
  "agent": "codex",
  "timestamp": "2026-03-08T14:15:00Z",
  "metadata": {
    "status": "in_progress",
    "tests_written": 3,
    "tests_passing": 2,
    "current_step": "Implementing parse_physical_adr()"
  }
}
```

**Monitoring**:
```python
# Cursor monitors CODEX progress
signals = read_signals("COMP-0005")
latest = signals[-1]
print(f"CODEX progress: {latest['metadata']['status']}")
print(f"Tests: {latest['metadata']['tests_passing']}/{latest['metadata']['tests_written']}")
```

### 3. Complete Signal

**Purpose**: Agent signals component implementation complete

**File**: `.codex/signals/ADR-P-XXXX/COMP-YYYY.complete.json`

```json
{
  "signal_type": "complete",
  "component_id": "COMP-0005",
  "adr_id": "ADR-P-0004",
  "agent": "codex",
  "timestamp": "2026-03-08T14:30:00Z",
  "metadata": {
    "tests_passing": 5,
    "tests_total": 5,
    "files_created": [
      "src/adr_kit/prompts/parser.py",
      "tests/test_component_parser.py"
    ],
    "invariants_enforced": ["INV-0027", "INV-0028", "INV-0029"]
  }
}
```

**Dependency checking**:
```python
# Agent B wants to implement COMP-0006 (depends on COMP-0005)
if not signal_exists("COMP-0005.complete.json"):
    print("Waiting for COMP-0005 to complete...")
    return
else:
    # COMP-0005 is done, proceed
    emit_claim("COMP-0006", agent="cursor")
```

### 4. Wave Complete Signal

**Purpose**: All components in a wave are complete

**File**: `.codex/signals/ADR-P-XXXX/wave-1.complete.json`

```json
{
  "signal_type": "wave_complete",
  "wave_num": 1,
  "adr_id": "ADR-P-0004",
  "timestamp": "2026-03-08T14:35:00Z",
  "metadata": {
    "components": ["COMP-0005", "COMP-0008"],
    "all_tests_passing": true,
    "next_wave": ["COMP-0006"]
  }
}
```

**Wave coordination**:
```python
# Check if Wave 1 is complete before starting Wave 2
if signal_exists("wave-1.complete.json"):
    print("Wave 1 complete, starting Wave 2 components...")
    # Can parallelize COMP-0006 and others in Wave 2
```

### 5. Validation Ready Signal

**Purpose**: Implementation complete, ready for validation

**File**: `.codex/signals/ADR-P-XXXX/validation-ready.json`

```json
{
  "signal_type": "validation_ready",
  "adr_id": "ADR-P-0004",
  "agent": "codex",
  "timestamp": "2026-03-08T15:00:00Z",
  "metadata": {
    "components_complete": 4,
    "tests_passing": 20,
    "tests_total": 20,
    "self_validation": "pass",
    "report": ".codex/reports/ADR-P-0004-completion.md"
  }
}
```

**Validator workflow**:
```python
# Cursor watches for validation-ready signal
if signal_exists("validation-ready.json"):
    signal = read_signal("validation-ready.json")
    print(f"Implementation ready for validation")
    print(f"Report: {signal['metadata']['report']}")
    # Start validation
```

---

## Signal Directory Structure

```
.codex/signals/
├── ADR-P-0004/                    # Per-ADR signals
│   ├── COMP-0005.claim.json       # Component claimed
│   ├── COMP-0005.progress.json    # Progress updates
│   ├── COMP-0005.complete.json    # Component done
│   ├── COMP-0006.claim.json
│   ├── COMP-0006.progress.json
│   ├── COMP-0006.complete.json
│   ├── wave-1.complete.json       # Wave coordination
│   ├── wave-2.complete.json
│   └── validation-ready.json      # Ready for validation
└── ADR-P-0005/                    # Next ADR
    └── ...
```

---

## Integration with Prompt Translator

### Enhanced CLI Output

```bash
python scripts/codex-implement.py ADR-P-0004 --agent codex

# Output includes signal setup:
# SUCCESS: Plan generated: .codex/plans/ADR-P-0004.md
#    Components: 4
#    Waves: 3
#    Signal directory: .codex/signals/ADR-P-0004/
#
# Cooperative signals enabled:
#    Agents can claim components to prevent conflicts
#    Progress visible in .codex/signals/ADR-P-0004/*.progress.json
#    Wave completion triggers next wave
#
# Ready for CODEX implementation
```

### Signal Generation in Prompts

**Each prompt includes signal instructions**:

```markdown
# Implementation Prompt: ComponentParser (COMP-0005)

## Before You Start

1. **Claim this component**:
   ```bash
   # Emit claim signal
   echo '{"signal_type": "claim", "component_id": "COMP-0005", "agent": "codex", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"}' > .codex/signals/ADR-P-0004/COMP-0005.claim.json
   ```

2. **Check if already claimed**:
   ```bash
   if [ -f .codex/signals/ADR-P-0004/COMP-0005.claim.json ]; then
       echo "Component already claimed by another agent"
       exit 1
   fi
   ```

## During Implementation

**Emit progress signals** periodically:
```bash
# After writing tests
echo '{"signal_type": "progress", "component_id": "COMP-0005", "agent": "codex", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'", "metadata": {"status": "tests_written", "tests_total": 5}}' > .codex/signals/ADR-P-0004/COMP-0005.progress.json

# After implementation
echo '{"signal_type": "progress", "component_id": "COMP-0005", "agent": "codex", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'", "metadata": {"status": "implementation_complete", "tests_passing": 5}}' > .codex/signals/ADR-P-0004/COMP-0005.progress.json
```

## After Completion

**Emit completion signal**:
```bash
echo '{"signal_type": "complete", "component_id": "COMP-0005", "agent": "codex", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'", "metadata": {"tests_passing": 5, "tests_total": 5}}' > .codex/signals/ADR-P-0004/COMP-0005.complete.json
```
```

---

## Monitoring Dashboard (Future)

**Script**: `scripts/monitor-signals.py`

```python
#!/usr/bin/env python3
"""Monitor cooperative signals from AI agents."""

import json
from pathlib import Path
from datetime import datetime

def monitor_adr(adr_id: str):
    """Monitor implementation progress for an ADR."""
    signal_dir = Path(f".codex/signals/{adr_id}")
    
    if not signal_dir.exists():
        print(f"No signals for {adr_id}")
        return
    
    print(f"Implementation Status: {adr_id}")
    print("=" * 60)
    
    # Read all signals
    for signal_file in sorted(signal_dir.glob("*.json")):
        with open(signal_file) as f:
            signal = json.load(f)
        
        component = signal.get("component_id", "N/A")
        agent = signal.get("agent", "unknown")
        signal_type = signal.get("signal_type")
        
        if signal_type == "claim":
            print(f"[CLAIMED] {component} by {agent}")
        elif signal_type == "progress":
            status = signal["metadata"]["status"]
            print(f"[PROGRESS] {component}: {status}")
        elif signal_type == "complete":
            tests = signal["metadata"]
            print(f"[COMPLETE] {component}: {tests['tests_passing']}/{tests['tests_total']} tests")
        elif signal_type == "wave_complete":
            wave = signal.get("wave_num")
            print(f"[WAVE {wave}] Complete")

if __name__ == '__main__':
    import sys
    monitor_adr(sys.argv[1] if len(sys.argv) > 1 else "ADR-P-0004")
```

**Usage**:
```bash
# Monitor implementation progress
python scripts/monitor-signals.py ADR-P-0004

# Output:
# Implementation Status: ADR-P-0004
# ============================================================
# [CLAIMED] COMP-0005 by codex
# [PROGRESS] COMP-0005: tests_written
# [PROGRESS] COMP-0005: implementation_complete
# [COMPLETE] COMP-0005: 5/5 tests
# [CLAIMED] COMP-0006 by cursor
# [PROGRESS] COMP-0006: in_progress
```

---

## Benefits

### For Parallel Agents
- Prevent duplicate work (claim signals)
- Know when dependencies satisfied (complete signals)
- Coordinate wave execution (wave complete signals)

### For Monitoring (Cursor)
- Real-time visibility into agent progress
- Know when to start validation (validation-ready signal)
- Track which agent is doing what

### For Coordination
- File-based (simple, no server needed)
- Instant visibility (same file system)
- Ephemeral (clean up after validation)

---

## Signal Lifecycle

```
1. Plan generated
   ↓ creates
   .codex/signals/ADR-P-XXXX/ (empty directory)

2. Agent claims component
   ↓ writes
   COMP-YYYY.claim.json

3. Agent implements (TDD)
   ↓ writes periodically
   COMP-YYYY.progress.json

4. Agent completes
   ↓ writes
   COMP-YYYY.complete.json

5. All wave components complete
   ↓ writes
   wave-N.complete.json

6. All components complete
   ↓ writes
   validation-ready.json

7. Validation complete
   ↓ deletes
   .codex/signals/ADR-P-XXXX/ (cleanup)
```

---

## Integration with Prompt Translator

### CLI Enhancement

```bash
# Generate prompts with signal support
python scripts/codex-implement.py ADR-P-0004 --agent codex --with-signals

# Creates:
# - .codex/plans/ADR-P-0004.md (implementation plan)
# - .codex/signals/ADR-P-0004/ (signal directory)
# - Prompts include signal emission instructions
```

### Prompt Template Enhancement

**Add signal instructions to each prompt**:

```jinja2
{# implementation-prompt.md.jinja2 #}

## Cooperative Signals

### Before Starting
```bash
# Check if component already claimed
if [ -f .codex/signals/{{ adr_id }}/{{ component.id }}.claim.json ]; then
    echo "Component {{ component.id }} already claimed"
    exit 1
fi

# Claim component
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'claim',
    'component_id': '{{ component.id }}',
    'adr_id': '{{ adr_id }}',
    'agent': '{{ agent }}',
    'timestamp': datetime.utcnow().isoformat() + 'Z'
}
with open('.codex/signals/{{ adr_id }}/{{ component.id }}.claim.json', 'w') as f:
    json.dump(signal, f, indent=2)
"
```

### During Implementation
```bash
# Emit progress signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'progress',
    'component_id': '{{ component.id }}',
    'agent': '{{ agent }}',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'status': 'in_progress', 'tests_passing': 2, 'tests_total': 5}
}
with open('.codex/signals/{{ adr_id }}/{{ component.id }}.progress.json', 'w') as f:
    json.dump(signal, f, indent=2)
"
```

### After Completion
```bash
# Emit completion signal
python -c "
import json
from datetime import datetime
signal = {
    'signal_type': 'complete',
    'component_id': '{{ component.id }}',
    'agent': '{{ agent }}',
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'metadata': {'tests_passing': 5, 'tests_total': 5}
}
with open('.codex/signals/{{ adr_id }}/{{ component.id }}.complete.json', 'w') as f:
    json.dump(signal, f, indent=2)
"
```
```

---

## Future: Rules & Signal Service Integration

**This is temporary** - when Rules & Signal Service (Tier 2) is built:

```
File-Based Signals (now)              Rules & Signal Service (future)
├─ .codex/signals/*.json       →     ├─ WebSocket/gRPC signals
├─ Manual signal emission      →     ├─ Automatic signal generation
├─ File polling for monitoring →     ├─ Real-time event streaming
└─ Local coordination only     →     └─ Cross-project coordination
```

**Migration path**:
1. File-based signals work now (no infrastructure)
2. RSS implements signal service
3. Agents switch to RSS API
4. File-based signals deprecated

---

## Signal Schema

**File**: `schema/v1.0/signal.schema.json` (future)

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["signal_type", "adr_id", "agent", "timestamp"],
  "properties": {
    "signal_type": {
      "type": "string",
      "enum": ["claim", "progress", "complete", "wave_complete", "validation_ready"]
    },
    "component_id": {"type": "string", "pattern": "^COMP-\\d{4}$"},
    "adr_id": {"type": "string", "pattern": "^ADR-[LP]-\\d{4}$"},
    "agent": {"type": "string", "enum": ["codex", "cursor", "claude", "gpt"]},
    "timestamp": {"type": "string", "format": "date-time"},
    "metadata": {"type": "object"}
  }
}
```

---

## Benefits of File-Based Signals

### Advantages
- Simple (just JSON files)
- No server required
- Instant visibility (same file system)
- Easy to debug (just read files)
- Works offline

### Limitations
- No real-time events (polling required)
- No cross-machine coordination
- Manual signal emission (agents must remember)
- No signal validation (until schema added)

**Good enough for now** - enables parallel work without infrastructure!

---

## Summary

**Cooperative signals enable**:
- Parallel agent coordination
- Progress monitoring
- Dependency satisfaction checking
- Validation triggering

**Temporary mechanism** until proper Rules & Signal Service built.

**Integration**: Prompt translator generates signal instructions in prompts.

**Not tracked in git**: `.codex/signals/` is ephemeral coordination, not project state.
