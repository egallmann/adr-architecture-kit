"""Test JSON Schema validation."""

import pytest
from pathlib import Path

from src.adr_kit.parser import ADRParser, ADRParseError, ADRSchemaValidationError


@pytest.fixture
def parser():
    """Create ADR parser."""
    return ADRParser()


@pytest.fixture
def fixtures_dir():
    """Get fixtures directory."""
    return Path(__file__).parent / "fixtures"


class TestValidLogicalADRs:
    """Test valid logical ADR parsing."""
    
    def test_minimal_logical_adr(self, parser, fixtures_dir):
        """Test parsing minimal valid logical ADR."""
        adr_path = fixtures_dir / "valid" / "logical-minimal.yaml"
        adr = parser.parse_logical_adr(adr_path)
        
        assert adr.id == "ADR-L-9999"
        assert adr.adr_type.value == "logical"
        assert adr.title == "Minimal Valid Logical ADR"
        assert len(adr.decisions) == 1
    
    def test_complete_logical_adr(self, parser):
        """Test parsing complete logical ADR (ADR-L-0001)."""
        adr_path = Path("adrs/logical/ADR-L-0001-ste-compliant-adr-system.yaml")
        
        if not adr_path.exists():
            pytest.skip("ADR-L-0001 not found")
        
        adr = parser.parse_logical_adr(adr_path)
        
        assert adr.id == "ADR-L-0001"
        assert adr.status.value == "accepted"
        assert len(adr.decisions) == 6
        assert len(adr.invariants) == 7
        assert len(adr.capabilities) == 7


class TestValidPhysicalADRs:
    """Test valid physical ADR parsing."""
    
    def test_minimal_physical_adr(self, parser, fixtures_dir):
        """Test parsing minimal valid physical ADR."""
        adr_path = fixtures_dir / "valid" / "physical-minimal.yaml"
        adr = parser.parse_physical_adr(adr_path)
        
        assert adr.id == "ADR-P-9999"
        assert adr.adr_type.value == "physical"
        assert len(adr.implements_logical) == 1
        assert adr.implements_logical[0] == "ADR-L-9999"
    
    def test_complete_physical_adr(self, parser):
        """Test parsing complete physical ADR (ADR-P-0001)."""
        adr_path = Path("adrs/physical/ADR-P-0001-python-toolkit-implementation.yaml")
        
        if not adr_path.exists():
            pytest.skip("ADR-P-0001 not found")
        
        adr = parser.parse_physical_adr(adr_path)
        
        assert adr.id == "ADR-P-0001"
        assert adr.status.value == "accepted"
        assert "ADR-L-0001" in adr.implements_logical
        assert len(adr.component_specifications) == 4


class TestInvalidADRs:
    """Test invalid ADR detection."""
    
    def test_missing_required_field(self, parser, fixtures_dir):
        """Test that missing required field is detected."""
        adr_path = fixtures_dir / "invalid" / "missing-required-field.yaml"
        
        with pytest.raises(ADRSchemaValidationError, match="'decisions' is a required property"):
            parser.parse_logical_adr(adr_path)
    
    def test_invalid_id_format(self, parser, fixtures_dir):
        """Test that invalid ID format is detected."""
        adr_path = fixtures_dir / "invalid" / "invalid-id-format.yaml"
        
        with pytest.raises((ADRSchemaValidationError, ADRParseError)):
            parser.parse_logical_adr(adr_path)


class TestIDPatternValidation:
    """Test ID pattern validation."""
    
    def test_logical_id_pattern(self, parser, fixtures_dir):
        """Test logical ADR ID must match ADR-L-XXXX pattern."""
        adr_path = fixtures_dir / "valid" / "logical-minimal.yaml"
        adr = parser.parse_logical_adr(adr_path)
        
        assert adr.id.startswith("ADR-L-")
        assert len(adr.id) == 10  # ADR-L-0001
    
    def test_physical_id_pattern(self, parser, fixtures_dir):
        """Test physical ADR ID must match ADR-P-XXXX pattern."""
        adr_path = fixtures_dir / "valid" / "physical-minimal.yaml"
        adr = parser.parse_physical_adr(adr_path)
        
        assert adr.id.startswith("ADR-P-")
        assert len(adr.id) == 10  # ADR-P-0001
